package jrame;

public class FrameMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameFrame game=new GameFrame();

	}

}
